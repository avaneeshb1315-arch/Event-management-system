@echo off
echo === Event Booking: Windows setup ===
python --version || (echo Install Python 3.11+ from python.org and tick "Add to PATH" & exit /b 1)
python -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Next: 1) edit .env and put your MySQL password
echo       2) mysql -u root -p ^< db\01_schema_and_seed.sql
echo       3) mysql -u root -p ^< db\02_booking_flow.sql
echo       4) venv\Scripts\activate ^&^& python app.py
