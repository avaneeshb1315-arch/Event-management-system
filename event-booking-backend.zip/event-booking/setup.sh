#!/usr/bin/env bash
set -e
python3 -m venv venv && source venv/bin/activate
pip install --upgrade pip && pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo "Next: edit .env, then:"
echo "  mysql -u root -p < db/01_schema_and_seed.sql"
echo "  mysql -u root -p < db/02_booking_flow.sql"
echo "  python app.py"
