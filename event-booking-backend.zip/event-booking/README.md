# Event Booking: Backend (Seating, Booking, Payment, Ticket, Check-in)

Flask + MySQL. Implements `booking-flow.md` (Rishvanth R). Every status change happens in a MySQL stored procedure, so the Booking, Payment and ShowSeat updates are always one transaction.

## 1. Install once
Python 3.11+ (python.org, tick "Add to PATH") · MySQL Server + Workbench 8.0.17+ (dev.mysql.com/downloads/installer) · Git · Postman (optional).

## 2. Set up
1. Run `setup.bat` (Windows) or `bash setup.sh`.
2. Put your MySQL password in `.env`.
3. `mysql -u root -p < db/01_schema_and_seed.sql`
4. `mysql -u root -p < db/02_booking_flow.sql`   (run after 01; run both again on a fresh DB, since 01 recreates it)
5. `venv\Scripts\activate` then `python app.py`, open http://localhost:5000/api/health

Razorpay runs in **mock mode** by default (`RAZORPAY_MOCK=true`): fake orders and refunds, unsigned webhooks accepted. For real test keys set `RAZORPAY_MOCK=false` and fill the three Razorpay values in `.env`. In Razorpay Dashboard add a webhook to `/api/payments/webhook` for `payment.captured` and `payment.failed`, with the same secret.

## 3. Endpoints (user is sent as header `X-User-Id`; seed users: 1-3 USER, 4 STAFF, 5 ADMIN)
| Doc API | URL | Body |
|---|---|---|
| POST /bookings | POST /api/bookings | {"event_id":1,"seat_ids":[1,2,3]} |
| POST /payments/create | POST /api/payments/create | {"booking_id":1} |
| POST /payments/webhook | POST /api/payments/webhook | Razorpay payload |
| GET /bookings/{id}/ticket | GET /api/bookings/1/ticket | |
| POST /bookings/{id}/cancel | POST /api/bookings/1/cancel | |
| POST /checkin | POST /api/checkin (STAFF/ADMIN) | {"qr_token":"..."} |
| extra | GET /api/events/1/seats, /availability, /api/bookings/1, /api/users/me/bookings | |
| extra | POST /api/admin/refunds/retry (ADMIN) | retries refunds that Razorpay rejected |

Errors: 409 = rule applied (seat taken, window closed, duplicate scan), 403 = not allowed, 404 = not found.

## 4. Try the whole flow (mock mode)
```
curl -X POST localhost:5000/api/bookings -H "X-User-Id: 1" -H "Content-Type: application/json" -d "{\"event_id\":1,\"seat_ids\":[1,2]}"
curl -X POST localhost:5000/api/payments/create -H "X-User-Id: 1" -H "Content-Type: application/json" -d "{\"booking_id\":1}"
   -> note order_id
curl -X POST localhost:5000/api/payments/webhook -H "Content-Type: application/json" -d "{\"event\":\"payment.captured\",\"payload\":{\"payment\":{\"entity\":{\"id\":\"pay_t1\",\"order_id\":\"<order_id>\"}}}}"
   -> CONFIRMED (send it again: DUPLICATE, nothing changes)
curl localhost:5000/api/bookings/1/ticket -H "X-User-Id: 1"         -> qr_token + qr_png
curl -X POST localhost:5000/api/checkin -H "X-User-Id: 4" -H "Content-Type: application/json" -d "{\"qr_token\":\"<qr_token>\"}"
   -> Checked in (scan again: 409 duplicate)
```

## 5. Doc table vs implementation
| Event | Where |
|---|---|
| POST /bookings: PENDING, seats Locked (HELD), server total | sp_create_booking |
| Webhook success: CONFIRMED, seats BOOKED, QR | sp_payment_success |
| Payment fails / lock expires: FAILED, seats freed | sp_payment_failed / sp_release_expired (every minute) |
| QR scan, second scan rejected | sp_checkin |
| Cancel after payment: refund / before payment: no refund | sp_cancel_booking + Razorpay refund |
Max 6 seats, one-seat-one-booking protection and webhook idempotency (`webhook_events`) are enforced in the database.

## 6. Decisions I made for the open questions (change if the team decides otherwise)
1. FAILED is an official Booking status: yes, implemented.
2. Paid after the lock expired: booking stays FAILED and the payment is refunded automatically (the suggestion in the doc). If the Razorpay refund call fails, it shows in `v_pending_refunds`; `/api/admin/refunds/retry` retries.
3. Cancellation window 24h before the event and 100% refund: placeholders in `.env` (`CANCEL_WINDOW_HOURS`, `REFUND_PERCENT`). Admin can cancel any time.
4. /checkin allowed for STAFF and ADMIN roles.
5. Confirmation email/SMS: not written; `notify_confirmation()` in `app.py` is the place to plug it in.

## 7. Not done / to know
- Login is a placeholder (`X-User-Id` header). Replace `current_user()` with the auth team's real check before going live.
- Not yet tested against a live MySQL/Razorpay: run section 4 first and report any error.
- No frontend in this package.
