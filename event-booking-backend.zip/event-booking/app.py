"""Event Booking API: seating, booking, payment (Razorpay), tickets and check-in.
Implements booking-flow.md. State changes happen inside MySQL stored procedures
(db/02_booking_flow.sql) so every status change is one transaction."""
import base64, hashlib, hmac, io, json, logging, os, uuid
from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS
import mysql.connector
import qrcode

load_dotenv()
app = Flask(__name__)
CORS(app)
log = logging.getLogger("booking")
logging.basicConfig(level=logging.INFO)

MOCK = os.getenv("RAZORPAY_MOCK", "true").lower() == "true"
LOCK_SECONDS = int(os.getenv("LOCK_SECONDS", 600))
CANCEL_WINDOW_HOURS = int(os.getenv("CANCEL_WINDOW_HOURS", 24))   # assumption, see README
REFUND_PERCENT = int(os.getenv("REFUND_PERCENT", 100))            # assumption, see README
WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")
rz = None
if not MOCK:
    import razorpay
    rz = razorpay.Client(auth=(os.getenv("RAZORPAY_KEY_ID"), os.getenv("RAZORPAY_KEY_SECRET")))

class ApiError(Exception):
    def __init__(self, msg, code=400): self.msg, self.code = msg, code

# ---------------------------------------------------------------- db helpers
def db():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"), port=int(os.getenv("DB_PORT", 3306)),
        user=os.getenv("DB_USER", "root"), password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "event_booking"))

def query(sql, params=()):
    con = db()
    try:
        cur = con.cursor(dictionary=True); cur.execute(sql, params)
        return cur.fetchall()
    finally:
        con.close()

def one(sql, params=()):
    rows = query(sql, params)
    return rows[0] if rows else None

def execute(sql, params=()):
    con = db()
    try:
        con.cursor().execute(sql, params); con.commit()
    finally:
        con.close()

def call(proc, args):
    """Call a stored procedure; returns the args list with OUT values filled in."""
    con = db()
    try:
        out = con.cursor().callproc(proc, args); con.commit()
        return out
    finally:
        con.close()

@app.errorhandler(ApiError)
def api_error(e):
    return jsonify(error=e.msg), e.code

@app.errorhandler(mysql.connector.Error)
def db_error(e):
    state = getattr(e, "sqlstate", "") or ""
    code = {"45000": 409, "45001": 403, "45002": 404}.get(state, 500)
    return jsonify(error=getattr(e, "msg", str(e))), code

# ---------------------------------------------------------------- auth (placeholder)
def current_user():
    """PLACEHOLDER: reads X-User-Id. Replace with the auth team's JWT/session check."""
    uid = request.headers.get("X-User-Id")
    if not uid or not uid.isdigit():
        raise ApiError("Missing X-User-Id header (login required)", 401)
    u = one("SELECT user_id, role FROM users WHERE user_id=%s", (int(uid),))
    if not u:
        raise ApiError("Unknown user", 401)
    return u

def own_booking(booking_id, user):
    b = one("SELECT * FROM bookings WHERE booking_id=%s", (booking_id,))
    if not b: raise ApiError("Booking not found", 404)
    if b["user_id"] != user["user_id"] and user["role"] not in ("ADMIN", "STAFF"):
        raise ApiError("Not your booking", 403)
    return b

# ---------------------------------------------------------------- razorpay (real or mock)
def rz_create_order(booking_id, amount):
    paise = int(round(float(amount) * 100))
    if MOCK:
        return "order_mock_" + uuid.uuid4().hex[:14], paise
    o = rz.order.create({"amount": paise, "currency": "INR", "receipt": f"BK{booking_id}",
                         "notes": {"booking_id": str(booking_id)}})
    return o["id"], paise

def rz_refund(payment_id, amount):
    paise = int(round(float(amount) * 100))
    if MOCK:
        return "rfnd_mock_" + uuid.uuid4().hex[:14]
    return rz.payment.refund(payment_id, {"amount": paise})["id"]

def refund_booking(booking_id, amount):
    """Call Razorpay, then record it. If Razorpay fails the row stays in v_pending_refunds."""
    p = one("SELECT razorpay_payment_id FROM payments WHERE booking_id=%s AND status='SUCCESS'", (booking_id,))
    if not p: return None
    try:
        rid = rz_refund(p["razorpay_payment_id"], amount)
        call("sp_mark_refunded", [booking_id, rid, float(amount)])
        return rid
    except Exception as ex:                      # keep going; admin can retry
        log.error("Refund failed for booking %s: %s", booking_id, ex)
        return None

def notify_confirmation(booking_id):
    """STUB (open question 5): plug email/SMS sending in here."""
    log.info("TODO send confirmation for booking %s", booking_id)

# ---------------------------------------------------------------- read endpoints
@app.get("/api/health")
def health():
    return jsonify(status="ok", razorpay_mock=MOCK)

@app.get("/api/events/<int:event_id>/seats")
def seats(event_id):
    return jsonify(query("SELECT * FROM v_seat_map WHERE event_id=%s ORDER BY row_label, seat_no", (event_id,)))

@app.get("/api/events/<int:event_id>/availability")
def availability(event_id):
    return jsonify(one("SELECT * FROM v_event_availability WHERE event_id=%s", (event_id,)) or {})

@app.get("/api/users/me/bookings")
def my_bookings():
    u = current_user()
    return jsonify(query("SELECT * FROM v_booking_history WHERE user_id=%s ORDER BY created_at DESC", (u["user_id"],)))

@app.get("/api/bookings/<int:booking_id>")
def booking_detail(booking_id):
    own_booking(booking_id, current_user())
    return jsonify(one("SELECT * FROM v_booking_history WHERE booking_id=%s", (booking_id,)))

# ---------------------------------------------------------------- POST /bookings
@app.post("/api/bookings")
def create_booking():
    u = current_user(); d = request.get_json(force=True)
    seat_ids = d.get("seat_ids") or []
    out = call("sp_create_booking", [d["event_id"], u["user_id"], json.dumps(seat_ids), LOCK_SECONDS, 0, 0])
    b = one("SELECT booking_id, status, total_amount, lock_expires_at FROM bookings WHERE booking_id=%s", (out[4],))
    return jsonify(b), 201

# ---------------------------------------------------------------- POST /payments/create
@app.post("/api/payments/create")
def payments_create():
    u = current_user(); d = request.get_json(force=True)
    b = own_booking(d["booking_id"], u)
    expired = one("SELECT lock_expires_at < NOW() AS x FROM bookings WHERE booking_id=%s", (b["booking_id"],))["x"]
    if b["status"] != "PENDING" or expired:
        raise ApiError("Booking is not payable (expired or not pending)", 409)
    p = one("SELECT * FROM payments WHERE booking_id=%s", (b["booking_id"],))
    if not p:
        order_id, paise = rz_create_order(b["booking_id"], b["total_amount"])   # amount from DB, not client
        execute("INSERT INTO payments (booking_id, razorpay_order_id, amount) VALUES (%s,%s,%s)",
                (b["booking_id"], order_id, b["total_amount"]))
    else:
        order_id, paise = p["razorpay_order_id"], int(round(float(p["amount"]) * 100))
    return jsonify(order_id=order_id, amount_paise=paise, currency="INR",
                   key_id=os.getenv("RAZORPAY_KEY_ID") or "mock"), 201

# ---------------------------------------------------------------- POST /payments/webhook
@app.post("/api/payments/webhook")
def payments_webhook():
    raw = request.get_data()
    if not MOCK:
        sig = request.headers.get("X-Razorpay-Signature", "")
        good = hmac.new(WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            raise ApiError("Bad signature", 400)
    evt = json.loads(raw)
    entity = evt["payload"]["payment"]["entity"]
    event_id = request.headers.get("X-Razorpay-Event-Id") or hashlib.sha256(raw).hexdigest()
    order_id, pay_id = entity["order_id"], entity["id"]

    if evt["event"] == "payment.captured":
        out = call("sp_payment_success", [order_id, pay_id, event_id, "", 0])
        result, booking_id = out[3], out[4]
        if result == "CONFIRMED":
            notify_confirmation(booking_id)
        elif result == "REFUND_REQUIRED":        # paid after lock expired -> automatic refund
            amt = one("SELECT amount FROM payments WHERE booking_id=%s", (booking_id,))["amount"]
            refund_booking(booking_id, amt)
    elif evt["event"] == "payment.failed":
        result = call("sp_payment_failed", [order_id, event_id, "", 0])[2]
    else:
        result = "IGNORED"
    return jsonify(result=result), 200           # always 200 so Razorpay does not loop

# ---------------------------------------------------------------- GET /bookings/{id}/ticket
@app.get("/api/bookings/<int:booking_id>/ticket")
def ticket(booking_id):
    own_booking(booking_id, current_user())
    b = one("SELECT * FROM v_booking_history WHERE booking_id=%s", (booking_id,))
    if b["status"] not in ("CONFIRMED", "CHECKED_IN"):
        raise ApiError("Ticket is available only for confirmed bookings", 409)
    token = one("SELECT qr_token FROM bookings WHERE booking_id=%s", (booking_id,))["qr_token"]
    buf = io.BytesIO(); qrcode.make(token).save(buf, format="PNG")
    b["qr_token"] = token
    b["qr_png"] = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    return jsonify(b)

# ---------------------------------------------------------------- POST /bookings/{id}/cancel
@app.post("/api/bookings/<int:booking_id>/cancel")
def cancel(booking_id):
    u = current_user(); admin = 1 if u["role"] == "ADMIN" else 0
    b = own_booking(booking_id, u)
    hours_left = one("SELECT TIMESTAMPDIFF(MINUTE, NOW(), starts_at) / 60 AS h FROM events WHERE event_id=%s",
                     (b["event_id"],))["h"]
    if b["status"] == "CONFIRMED" and not admin and hours_left < CANCEL_WINDOW_HOURS:
        raise ApiError(f"Cancellation closed: allowed until {CANCEL_WINDOW_HOURS}h before the event", 409)
    out = call("sp_cancel_booking", [booking_id, u["user_id"], admin, "", 0])
    result, paid = out[3], out[4]
    refund_id = None
    if result == "REFUND_REQUIRED":
        refund_id = refund_booking(booking_id, float(paid) * REFUND_PERCENT / 100)
    return jsonify(status="CANCELLED", refund_started=result == "REFUND_REQUIRED",
                   refunded=refund_id is not None, refund_id=refund_id)

# ---------------------------------------------------------------- POST /checkin
@app.post("/api/checkin")
def checkin():
    u = current_user(); d = request.get_json(force=True)
    out = call("sp_checkin", [d["qr_token"], u["user_id"], 0])
    return jsonify(message="Checked in", booking_id=out[2])

# ---------------------------------------------------------------- admin: retry stuck refunds
@app.post("/api/admin/refunds/retry")
def retry_refunds():
    if current_user()["role"] != "ADMIN": raise ApiError("Admin only", 403)
    done = []
    for r in query("SELECT booking_id, amount FROM v_pending_refunds"):
        if refund_booking(r["booking_id"], r["amount"]): done.append(r["booking_id"])
    return jsonify(refunded_booking_ids=done)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
