-- =====================================================================
--  02_booking_flow.sql : implements booking-flow.md (Rishvanth R)
--  Run AFTER 01_schema_and_seed.sql.
--  Mapping: ShowSeat = event_seats, "Locked" = HELD, "Booked" = BOOKED.
--  SQLSTATE codes raised by the procedures:
--    45000 = rule conflict (409)   45001 = not allowed (403)   45002 = not found (404)
-- =====================================================================
USE event_booking;

DROP PROCEDURE IF EXISTS sp_hold_seats;
DROP PROCEDURE IF EXISTS sp_confirm_booking;
DROP PROCEDURE IF EXISTS sp_release_holds;
DROP PROCEDURE IF EXISTS sp_cancel_booking;
DROP PROCEDURE IF EXISTS sp_release_expired;

-- ---------- tables / columns ----------
ALTER TABLE users
  ADD COLUMN role ENUM('USER','STAFF','ADMIN') NOT NULL DEFAULT 'USER';

ALTER TABLE bookings
  MODIFY status ENUM('PENDING','CONFIRMED','FAILED','CANCELLED','CHECKED_IN') NOT NULL DEFAULT 'PENDING',
  ADD COLUMN lock_expires_at DATETIME NULL,
  ADD COLUMN qr_token CHAR(36) NULL,
  ADD COLUMN checked_in_at DATETIME NULL,
  ADD COLUMN checked_in_by INT NULL,
  ADD UNIQUE KEY uq_qr_token (qr_token),
  ADD CONSTRAINT fk_bk_staff FOREIGN KEY (checked_in_by) REFERENCES users(user_id);

CREATE TABLE payments (
  payment_id           INT AUTO_INCREMENT PRIMARY KEY,
  booking_id           INT NOT NULL UNIQUE,
  razorpay_order_id    VARCHAR(64) NOT NULL UNIQUE,
  razorpay_payment_id  VARCHAR(64) NULL UNIQUE,
  amount               DECIMAL(10,2) NOT NULL,
  status               ENUM('PENDING','SUCCESS','FAILED','REFUNDED') NOT NULL DEFAULT 'PENDING',
  refund_id            VARCHAR(64) NULL,
  refunded_amount      DECIMAL(10,2) NULL,
  created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_pay_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
) ENGINE=InnoDB;

-- one row per processed webhook event: makes the webhook idempotent
CREATE TABLE webhook_events (
  event_id     VARCHAR(100) PRIMARY KEY,
  event_type   VARCHAR(50) NOT NULL,
  received_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO users (name, email, role) VALUES
  ('Gate Staff', 'staff@example.com', 'STAFF'),   -- user_id 4
  ('Admin',      'admin@example.com', 'ADMIN');   -- user_id 5

-- ---------- views ----------
CREATE OR REPLACE VIEW v_booking_history AS
SELECT b.booking_id, b.user_id, b.event_id, e.title, e.starts_at, b.status,
       b.total_amount, b.lock_expires_at, b.created_at, b.cancelled_at, b.checked_in_at,
       ANY_VALUE(p.status) AS payment_status,
       GROUP_CONCAT(CONCAT(s.row_label, s.seat_no) ORDER BY s.row_label, s.seat_no SEPARATOR ', ') AS seats
FROM bookings b
JOIN events e ON e.event_id = b.event_id
JOIN booking_seats bs ON bs.booking_id = b.booking_id
JOIN seats s ON s.seat_id = bs.seat_id
LEFT JOIN payments p ON p.booking_id = b.booking_id
GROUP BY b.booking_id;

-- money captured but booking is not CONFIRMED/CHECKED_IN and not refunded yet
CREATE VIEW v_pending_refunds AS
SELECT b.booking_id, b.status AS booking_status, p.razorpay_payment_id, p.amount
FROM payments p JOIN bookings b ON b.booking_id = p.booking_id
WHERE p.status = 'SUCCESS' AND b.status IN ('FAILED','CANCELLED');

DELIMITER $$

-- internal helper: give a booking's seats back
CREATE PROCEDURE sp_free_booking_seats(IN p_booking INT)
BEGIN
  UPDATE booking_seats SET is_active = 0 WHERE booking_id = p_booking;
  UPDATE event_seats
     SET status='AVAILABLE', held_by=NULL, hold_expires_at=NULL, booking_id=NULL
   WHERE booking_id = p_booking AND status IN ('HELD','BOOKED');
END$$

-- "Release job": closes PENDING bookings whose lock has expired (run every minute)
CREATE PROCEDURE sp_release_expired()
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  START TRANSACTION;
  INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
    SELECT event_id, seat_id, 'EXPIRE', held_by, booking_id FROM event_seats
     WHERE status='HELD' AND booking_id IN
       (SELECT booking_id FROM bookings WHERE status='PENDING' AND lock_expires_at < NOW());
  UPDATE booking_seats SET is_active = 0 WHERE booking_id IN
       (SELECT booking_id FROM bookings WHERE status='PENDING' AND lock_expires_at < NOW());
  UPDATE event_seats SET status='AVAILABLE', held_by=NULL, hold_expires_at=NULL, booking_id=NULL
   WHERE status='HELD' AND booking_id IN
       (SELECT booking_id FROM bookings WHERE status='PENDING' AND lock_expires_at < NOW());
  UPDATE bookings SET status='FAILED' WHERE status='PENDING' AND lock_expires_at < NOW();
  COMMIT;
END$$

-- POST /bookings : lock seats + create PENDING booking. Total comes from event_seats.price.
CREATE PROCEDURE sp_create_booking(IN p_event INT, IN p_user INT, IN p_seats JSON, IN p_lock_secs INT,
                                   OUT p_booking_id INT, OUT p_total DECIMAL(10,2))
BEGIN
  DECLARE v_req INT; DECLARE v_exp DATETIME;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

  SET v_req = JSON_LENGTH(p_seats);
  IF v_req IS NULL OR v_req < 1 OR v_req > 6 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Select between 1 and 6 seats';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM events WHERE event_id=p_event AND status='SCHEDULED' AND starts_at > NOW()) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Event is not open for booking';
  END IF;

  CALL sp_release_expired();             -- free stale locks first
  SET v_exp = DATE_ADD(NOW(), INTERVAL p_lock_secs SECOND);

  START TRANSACTION;
  INSERT INTO bookings (user_id, event_id, total_amount, status, lock_expires_at)
  VALUES (p_user, p_event, 0, 'PENDING', v_exp);
  SET p_booking_id = LAST_INSERT_ID();

  -- atomic claim: only AVAILABLE seats change, so two users can never get the same seat
  UPDATE event_seats
     SET status='HELD', held_by=p_user, hold_expires_at=v_exp, booking_id=p_booking_id
   WHERE event_id=p_event AND status='AVAILABLE' AND seat_id MEMBER OF (p_seats);
  IF ROW_COUNT() <> v_req THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'One or more seats are not available';
  END IF;

  SELECT SUM(price) INTO p_total FROM event_seats WHERE booking_id = p_booking_id;
  UPDATE bookings SET total_amount = p_total WHERE booking_id = p_booking_id;
  INSERT INTO booking_seats (booking_id, event_id, seat_id, price)
    SELECT p_booking_id, event_id, seat_id, price FROM event_seats WHERE booking_id = p_booking_id;
  INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
    SELECT event_id, seat_id, 'HOLD', p_user, p_booking_id FROM event_seats WHERE booking_id = p_booking_id;
  COMMIT;
END$$

-- Webhook: payment.captured. Idempotent. p_result: CONFIRMED | REFUND_REQUIRED | DUPLICATE | UNKNOWN_ORDER
CREATE PROCEDURE sp_payment_success(IN p_order VARCHAR(64), IN p_pay VARCHAR(64), IN p_evt VARCHAR(100),
                                    OUT p_result VARCHAR(20), OUT p_booking_id INT)
main: BEGIN
  DECLARE v_new INT; DECLARE v_pay_status VARCHAR(20);
  DECLARE v_bstatus VARCHAR(20); DECLARE v_exp DATETIME;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  SET p_result = NULL; SET p_booking_id = NULL;

  START TRANSACTION;
  INSERT IGNORE INTO webhook_events (event_id, event_type) VALUES (p_evt, 'payment.captured');
  SET v_new = ROW_COUNT();
  SELECT booking_id, status INTO p_booking_id, v_pay_status
    FROM payments WHERE razorpay_order_id = p_order FOR UPDATE;
  IF p_booking_id IS NULL THEN SET p_result='UNKNOWN_ORDER'; COMMIT; LEAVE main; END IF;
  IF v_new = 0 OR v_pay_status <> 'PENDING' THEN SET p_result='DUPLICATE'; COMMIT; LEAVE main; END IF;

  SELECT status, lock_expires_at INTO v_bstatus, v_exp FROM bookings WHERE booking_id = p_booking_id FOR UPDATE;
  UPDATE payments SET status='SUCCESS', razorpay_payment_id=p_pay WHERE booking_id = p_booking_id;

  IF v_bstatus = 'PENDING' AND v_exp >= NOW() THEN
    INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
      SELECT event_id, seat_id, 'CONFIRM', held_by, booking_id FROM event_seats
       WHERE booking_id = p_booking_id AND status='HELD';
    UPDATE event_seats SET status='BOOKED', held_by=NULL, hold_expires_at=NULL
     WHERE booking_id = p_booking_id AND status='HELD';
    UPDATE bookings SET status='CONFIRMED', qr_token=UUID() WHERE booking_id = p_booking_id;
    SET p_result = 'CONFIRMED';
  ELSE
    -- paid after the lock expired (or booking already cancelled/failed): refund automatically
    IF v_bstatus = 'PENDING' THEN
      CALL sp_free_booking_seats(p_booking_id);
      UPDATE bookings SET status='FAILED' WHERE booking_id = p_booking_id;
    END IF;
    SET p_result = 'REFUND_REQUIRED';
  END IF;
  COMMIT;
END$$

-- Webhook: payment.failed. Booking FAILED, seats released.
CREATE PROCEDURE sp_payment_failed(IN p_order VARCHAR(64), IN p_evt VARCHAR(100),
                                   OUT p_result VARCHAR(20), OUT p_booking_id INT)
main: BEGIN
  DECLARE v_new INT; DECLARE v_pay_status VARCHAR(20); DECLARE v_bstatus VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  SET p_result = NULL; SET p_booking_id = NULL;

  START TRANSACTION;
  INSERT IGNORE INTO webhook_events (event_id, event_type) VALUES (p_evt, 'payment.failed');
  SET v_new = ROW_COUNT();
  SELECT booking_id, status INTO p_booking_id, v_pay_status
    FROM payments WHERE razorpay_order_id = p_order FOR UPDATE;
  IF p_booking_id IS NULL THEN SET p_result='UNKNOWN_ORDER'; COMMIT; LEAVE main; END IF;
  IF v_new = 0 OR v_pay_status <> 'PENDING' THEN SET p_result='DUPLICATE'; COMMIT; LEAVE main; END IF;

  SELECT status INTO v_bstatus FROM bookings WHERE booking_id = p_booking_id FOR UPDATE;
  UPDATE payments SET status='FAILED' WHERE booking_id = p_booking_id;
  IF v_bstatus = 'PENDING' THEN
    CALL sp_free_booking_seats(p_booking_id);
    UPDATE bookings SET status='FAILED' WHERE booking_id = p_booking_id;
  END IF;
  SET p_result = 'FAILED';
  COMMIT;
END$$

-- POST /bookings/{id}/cancel. p_result: CANCELLED | REFUND_REQUIRED (caller then calls Razorpay refund)
CREATE PROCEDURE sp_cancel_booking(IN p_booking INT, IN p_user INT, IN p_is_admin TINYINT,
                                   OUT p_result VARCHAR(20), OUT p_paid DECIMAL(10,2))
BEGIN
  DECLARE v_owner INT; DECLARE v_status VARCHAR(20); DECLARE v_total DECIMAL(10,2);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  SET p_paid = 0;

  START TRANSACTION;
  SELECT user_id, status, total_amount INTO v_owner, v_status, v_total
    FROM bookings WHERE booking_id = p_booking FOR UPDATE;
  IF v_owner IS NULL THEN
    SIGNAL SQLSTATE '45002' SET MESSAGE_TEXT = 'Booking not found';
  END IF;
  IF v_owner <> p_user AND p_is_admin = 0 THEN
    SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT = 'Not your booking';
  END IF;
  IF v_status NOT IN ('PENDING','CONFIRMED') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only PENDING or CONFIRMED bookings can be cancelled';
  END IF;

  INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
    SELECT event_id, seat_id, 'CANCEL', p_user, p_booking FROM event_seats WHERE booking_id = p_booking;
  CALL sp_free_booking_seats(p_booking);
  UPDATE bookings SET status='CANCELLED', cancelled_at=NOW() WHERE booking_id = p_booking;

  IF v_status = 'CONFIRMED' THEN SET p_result='REFUND_REQUIRED'; SET p_paid = v_total;
  ELSE SET p_result = 'CANCELLED';          -- cancelled before payment: no refund
  END IF;
  COMMIT;
END$$

-- After Razorpay confirms the refund
CREATE PROCEDURE sp_mark_refunded(IN p_booking INT, IN p_refund_id VARCHAR(64), IN p_amount DECIMAL(10,2))
BEGIN
  UPDATE payments SET status='REFUNDED', refund_id=p_refund_id, refunded_amount=p_amount
   WHERE booking_id = p_booking AND status = 'SUCCESS';
END$$

-- POST /checkin : STAFF/ADMIN scan a QR. A second scan is rejected.
CREATE PROCEDURE sp_checkin(IN p_token CHAR(36), IN p_staff INT, OUT p_booking_id INT)
BEGIN
  DECLARE v_role VARCHAR(10); DECLARE v_status VARCHAR(20); DECLARE v_when DATETIME;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

  SELECT role INTO v_role FROM users WHERE user_id = p_staff;
  IF v_role IS NULL OR v_role NOT IN ('STAFF','ADMIN') THEN
    SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT = 'Only staff or admin can check in tickets';
  END IF;

  START TRANSACTION;
  SELECT booking_id, status, checked_in_at INTO p_booking_id, v_status, v_when
    FROM bookings WHERE qr_token = p_token FOR UPDATE;
  IF p_booking_id IS NULL THEN
    SIGNAL SQLSTATE '45002' SET MESSAGE_TEXT = 'Unknown QR code';
  END IF;
  IF v_status = 'CHECKED_IN' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Duplicate scan: ticket already checked in';
  END IF;
  IF v_status <> 'CONFIRMED' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ticket is not valid for entry';
  END IF;
  UPDATE bookings SET status='CHECKED_IN', checked_in_at=NOW(), checked_in_by=p_staff
   WHERE booking_id = p_booking_id;
  COMMIT;
END$$

DELIMITER ;

-- The 1-minute scheduler job from file 01 already calls sp_release_expired().
-- If it is off:  SET GLOBAL event_scheduler = ON;
