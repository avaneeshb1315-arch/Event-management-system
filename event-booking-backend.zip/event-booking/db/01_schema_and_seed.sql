-- =====================================================================
--  EVENT MANAGEMENT SYSTEM : SEATING & BOOKING MODULE  (MySQL 8.0.17+)
--  One file: schema + constraints + stored procedures + scheduler
--            + seed data + demo/test script.
--  Run:  mysql -u root -p < seat_booking_db.sql
--        (or open in MySQL Workbench and run all)
-- =====================================================================
--  API  ->  DB call
--  GET  /events/{id}/seats        SELECT * FROM v_seat_map WHERE event_id = ?
--  POST /bookings/hold            CALL sp_hold_seats(event, user, '[1,2,3]', 300)
--  POST /bookings/confirm         CALL sp_confirm_booking(event, user, 'PAY-REF', @bid)
--  DELETE /bookings/{id}          CALL sp_cancel_booking(booking_id, user)
--  POST /holds/release            CALL sp_release_holds(event, user)
--  GET  /users/{id}/bookings      SELECT * FROM v_booking_history WHERE user_id = ?
-- =====================================================================

DROP DATABASE IF EXISTS event_booking;
CREATE DATABASE event_booking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_booking;

-- ---------------------------------------------------------------------
-- 1. TABLES
-- ---------------------------------------------------------------------
CREATE TABLE users (
  user_id     INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE venues (
  venue_id    INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  address     VARCHAR(255)
) ENGINE=InnoDB;

-- Physical seats of a venue (layout). Same layout is reused by many events.
CREATE TABLE seats (
  seat_id     INT AUTO_INCREMENT PRIMARY KEY,
  venue_id    INT NOT NULL,
  row_label   CHAR(2) NOT NULL,
  seat_no     TINYINT UNSIGNED NOT NULL,
  seat_type   ENUM('REGULAR','VIP') NOT NULL DEFAULT 'REGULAR',
  base_price  DECIMAL(10,2) NOT NULL CHECK (base_price >= 0),
  UNIQUE KEY uq_seat_position (venue_id, row_label, seat_no),
  CONSTRAINT fk_seat_venue FOREIGN KEY (venue_id) REFERENCES venues(venue_id)
) ENGINE=InnoDB;

CREATE TABLE events (
  event_id    INT AUTO_INCREMENT PRIMARY KEY,
  venue_id    INT NOT NULL,
  title       VARCHAR(200) NOT NULL,
  starts_at   DATETIME NOT NULL,
  status      ENUM('SCHEDULED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'SCHEDULED',
  CONSTRAINT fk_event_venue FOREIGN KEY (venue_id) REFERENCES venues(venue_id)
) ENGINE=InnoDB;

CREATE TABLE bookings (
  booking_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  event_id      INT NOT NULL,
  total_amount  DECIMAL(10,2) NOT NULL,
  payment_ref   VARCHAR(100),
  status        ENUM('CONFIRMED','CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cancelled_at  TIMESTAMP NULL,
  CONSTRAINT fk_bk_user  FOREIGN KEY (user_id)  REFERENCES users(user_id),
  CONSTRAINT fk_bk_event FOREIGN KEY (event_id) REFERENCES events(event_id),
  INDEX idx_bk_user (user_id)
) ENGINE=InnoDB;

-- Live state of every seat for every event (this is the table that is locked).
CREATE TABLE event_seats (
  event_id         INT NOT NULL,
  seat_id          INT NOT NULL,
  price            DECIMAL(10,2) NOT NULL,
  status           ENUM('AVAILABLE','HELD','BOOKED','BLOCKED') NOT NULL DEFAULT 'AVAILABLE',
  held_by          INT NULL,
  hold_expires_at  DATETIME NULL,
  booking_id       INT NULL,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (event_id, seat_id),
  CONSTRAINT fk_es_event   FOREIGN KEY (event_id)   REFERENCES events(event_id),
  CONSTRAINT fk_es_seat    FOREIGN KEY (seat_id)    REFERENCES seats(seat_id),
  CONSTRAINT fk_es_user    FOREIGN KEY (held_by)    REFERENCES users(user_id),
  CONSTRAINT fk_es_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
  -- a HELD seat must have an owner and an expiry; others must not
  CONSTRAINT ck_hold_fields CHECK (
    (status = 'HELD' AND held_by IS NOT NULL AND hold_expires_at IS NOT NULL)
    OR (status <> 'HELD' AND held_by IS NULL AND hold_expires_at IS NULL)),
  INDEX idx_es_status (event_id, status),
  INDEX idx_es_holder (held_by),
  INDEX idx_es_expiry (status, hold_expires_at)
) ENGINE=InnoDB;

-- Seats inside a booking. The generated column + UNIQUE key is the last line of
-- defence: the same seat can never be in two ACTIVE bookings for one event.
CREATE TABLE booking_seats (
  booking_id      INT NOT NULL,
  event_id        INT NOT NULL,
  seat_id         INT NOT NULL,
  price           DECIMAL(10,2) NOT NULL,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  active_seat_id  INT GENERATED ALWAYS AS (IF(is_active = 1, seat_id, NULL)) STORED,
  PRIMARY KEY (booking_id, seat_id),
  UNIQUE KEY uq_one_active_booking_per_seat (event_id, active_seat_id),
  CONSTRAINT fk_bs_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id),
  CONSTRAINT fk_bs_seat    FOREIGN KEY (event_id, seat_id) REFERENCES event_seats(event_id, seat_id)
) ENGINE=InnoDB;

-- Audit trail of every seat state change.
CREATE TABLE seat_audit (
  audit_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
  event_id    INT NOT NULL,
  seat_id     INT NOT NULL,
  action      VARCHAR(30) NOT NULL,   -- HOLD, RELEASE, EXPIRE, CONFIRM, CANCEL
  user_id     INT NULL,
  booking_id  INT NULL,
  at_time     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_seat (event_id, seat_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. VIEWS
-- ---------------------------------------------------------------------
-- Seat map for the UI. An expired hold is shown as AVAILABLE immediately,
-- even before the cleanup job runs.
CREATE VIEW v_seat_map AS
SELECT es.event_id, s.seat_id, s.row_label, s.seat_no, s.seat_type, es.price,
       CASE WHEN es.status = 'HELD' AND es.hold_expires_at < NOW()
            THEN 'AVAILABLE' ELSE es.status END AS status,
       CASE WHEN es.status = 'HELD' AND es.hold_expires_at >= NOW()
            THEN es.held_by END AS held_by,
       CASE WHEN es.status = 'HELD' AND es.hold_expires_at >= NOW()
            THEN es.hold_expires_at END AS hold_expires_at
FROM event_seats es JOIN seats s ON s.seat_id = es.seat_id;

CREATE VIEW v_event_availability AS
SELECT event_id,
       SUM(status = 'AVAILABLE') AS available,
       SUM(status = 'HELD')      AS held,
       SUM(status = 'BOOKED')    AS booked,
       SUM(status = 'BLOCKED')   AS blocked,
       COUNT(*)                  AS total
FROM v_seat_map GROUP BY event_id;

CREATE VIEW v_booking_history AS
SELECT b.booking_id, b.user_id, b.event_id, e.title, e.starts_at, b.status,
       b.total_amount, b.created_at, b.cancelled_at,
       GROUP_CONCAT(CONCAT(s.row_label, s.seat_no) ORDER BY s.row_label, s.seat_no SEPARATOR ', ') AS seats
FROM bookings b
JOIN events e ON e.event_id = b.event_id
JOIN booking_seats bs ON bs.booking_id = b.booking_id
JOIN seats s ON s.seat_id = bs.seat_id
GROUP BY b.booking_id;

-- ---------------------------------------------------------------------
-- 3. STORED PROCEDURES (the booking logic)
-- ---------------------------------------------------------------------
DELIMITER $$

-- Release every expired hold (used by the scheduler and by other procedures)
CREATE PROCEDURE sp_release_expired()
BEGIN
  INSERT INTO seat_audit (event_id, seat_id, action, user_id)
    SELECT event_id, seat_id, 'EXPIRE', held_by FROM event_seats
    WHERE status = 'HELD' AND hold_expires_at < NOW();
  UPDATE event_seats
     SET status = 'AVAILABLE', held_by = NULL, hold_expires_at = NULL
   WHERE status = 'HELD' AND hold_expires_at < NOW();
END$$

-- HOLD: p_seats is a JSON array of seat_ids, e.g. '[3,4,5]'. All or nothing.
CREATE PROCEDURE sp_hold_seats(IN p_event INT, IN p_user INT, IN p_seats JSON, IN p_secs INT)
BEGIN
  DECLARE v_req INT;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

  SET v_req = JSON_LENGTH(p_seats);
  IF v_req IS NULL OR v_req < 1 OR v_req > 6 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Select between 1 and 6 seats';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM events WHERE event_id = p_event AND status = 'SCHEDULED' AND starts_at > NOW()) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Event is not open for booking';
  END IF;

  START TRANSACTION;
  -- free expired holds on the requested seats first
  UPDATE event_seats SET status='AVAILABLE', held_by=NULL, hold_expires_at=NULL
   WHERE event_id = p_event AND status = 'HELD' AND hold_expires_at < NOW();

  -- Atomic claim: the UPDATE takes row locks and only touches AVAILABLE seats.
  UPDATE event_seats
     SET status = 'HELD', held_by = p_user,
         hold_expires_at = DATE_ADD(NOW(), INTERVAL p_secs SECOND)
   WHERE event_id = p_event AND status = 'AVAILABLE' AND seat_id MEMBER OF (p_seats);

  IF ROW_COUNT() <> v_req THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'One or more seats are not available';
  END IF;

  INSERT INTO seat_audit (event_id, seat_id, action, user_id)
    SELECT p_event, seat_id, 'HOLD', p_user FROM event_seats
    WHERE event_id = p_event AND held_by = p_user AND seat_id MEMBER OF (p_seats);
  COMMIT;
END$$

-- CONFIRM: turns the caller's live holds for the event into one booking.
CREATE PROCEDURE sp_confirm_booking(IN p_event INT, IN p_user INT, IN p_payment_ref VARCHAR(100), OUT p_booking_id INT)
BEGIN
  DECLARE v_cnt INT; DECLARE v_total DECIMAL(10,2);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

  START TRANSACTION;
  SELECT COUNT(*), COALESCE(SUM(price),0) INTO v_cnt, v_total
    FROM event_seats
   WHERE event_id = p_event AND held_by = p_user AND status = 'HELD' AND hold_expires_at >= NOW()
   FOR UPDATE;
  IF v_cnt = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active hold found (it may have expired)';
  END IF;

  INSERT INTO bookings (user_id, event_id, total_amount, payment_ref)
  VALUES (p_user, p_event, v_total, p_payment_ref);
  SET p_booking_id = LAST_INSERT_ID();

  INSERT INTO booking_seats (booking_id, event_id, seat_id, price)
    SELECT p_booking_id, event_id, seat_id, price FROM event_seats
     WHERE event_id = p_event AND held_by = p_user AND status = 'HELD' AND hold_expires_at >= NOW();

  INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
    SELECT event_id, seat_id, 'CONFIRM', p_user, p_booking_id FROM event_seats
     WHERE event_id = p_event AND held_by = p_user AND status = 'HELD';

  UPDATE event_seats
     SET status = 'BOOKED', booking_id = p_booking_id, held_by = NULL, hold_expires_at = NULL
   WHERE event_id = p_event AND held_by = p_user AND status = 'HELD' AND hold_expires_at >= NOW();
  COMMIT;
END$$

-- CANCEL: only the owner can cancel, and only a CONFIRMED booking (safe to repeat).
CREATE PROCEDURE sp_cancel_booking(IN p_booking INT, IN p_user INT)
BEGIN
  DECLARE v_event INT; DECLARE v_status VARCHAR(20);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

  START TRANSACTION;
  SELECT event_id, status INTO v_event, v_status FROM bookings
   WHERE booking_id = p_booking AND user_id = p_user FOR UPDATE;
  IF v_event IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Booking not found for this user';
  END IF;
  IF v_status = 'CANCELLED' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Booking is already cancelled';
  END IF;

  UPDATE booking_seats SET is_active = 0 WHERE booking_id = p_booking;
  INSERT INTO seat_audit (event_id, seat_id, action, user_id, booking_id)
    SELECT event_id, seat_id, 'CANCEL', p_user, p_booking FROM event_seats WHERE booking_id = p_booking;
  UPDATE event_seats SET status = 'AVAILABLE', booking_id = NULL WHERE booking_id = p_booking;
  UPDATE bookings SET status = 'CANCELLED', cancelled_at = NOW() WHERE booking_id = p_booking;
  COMMIT;
END$$

-- Give up the caller's holds before they expire
CREATE PROCEDURE sp_release_holds(IN p_event INT, IN p_user INT)
BEGIN
  INSERT INTO seat_audit (event_id, seat_id, action, user_id)
    SELECT event_id, seat_id, 'RELEASE', p_user FROM event_seats
     WHERE event_id = p_event AND held_by = p_user AND status = 'HELD';
  UPDATE event_seats SET status='AVAILABLE', held_by=NULL, hold_expires_at=NULL
   WHERE event_id = p_event AND held_by = p_user AND status = 'HELD';
END$$

-- ADMIN: block / unblock a seat (only when it is free)
CREATE PROCEDURE sp_admin_set_block(IN p_event INT, IN p_seat INT, IN p_block TINYINT)
BEGIN
  IF p_block = 1 THEN
    UPDATE event_seats SET status='BLOCKED' WHERE event_id=p_event AND seat_id=p_seat AND status='AVAILABLE';
  ELSE
    UPDATE event_seats SET status='AVAILABLE' WHERE event_id=p_event AND seat_id=p_seat AND status='BLOCKED';
  END IF;
  IF ROW_COUNT() = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Seat state did not allow this change';
  END IF;
END$$

DELIMITER ;

-- ---------------------------------------------------------------------
-- 4. SCHEDULER: clean up expired holds every minute
--    (needs the scheduler on; if your server blocks it, run: CALL sp_release_expired();
--     from the app every minute. The v_seat_map view already hides expired holds.)
-- ---------------------------------------------------------------------
SET GLOBAL event_scheduler = ON;
CREATE EVENT ev_release_expired_holds
  ON SCHEDULE EVERY 1 MINUTE
  DO CALL sp_release_expired();

-- ---------------------------------------------------------------------
-- 5. SEED DATA (sample venue: 8 rows A-H x 12 seats; rows A-B are VIP)
-- ---------------------------------------------------------------------
INSERT INTO users (name, email) VALUES
  ('Avaneesh', 'avaneesh@example.com'),
  ('Test User 2', 'user2@example.com'),
  ('Test User 3', 'user3@example.com');

INSERT INTO venues (name, address) VALUES ('Main Auditorium', 'Chennai');

INSERT INTO seats (venue_id, row_label, seat_no, seat_type, base_price)
WITH RECURSIVE r AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM r WHERE n < 8),
               c AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM c WHERE n < 12)
SELECT 1, CHAR(64 + r.n), c.n, IF(r.n <= 2, 'VIP', 'REGULAR'), IF(r.n <= 2, 500, 250)
FROM r CROSS JOIN c;

INSERT INTO events (venue_id, title, starts_at) VALUES
  (1, 'Tech Fest Keynote', '2026-12-20 18:00:00'),
  (1, 'Carnatic Night',    '2026-12-27 19:30:00');

-- create one live row per seat for each event
INSERT INTO event_seats (event_id, seat_id, price)
SELECT e.event_id, s.seat_id, s.base_price
FROM events e JOIN seats s ON s.venue_id = e.venue_id;

-- (Demo calls removed. Now run db/02_booking_flow.sql next.)
